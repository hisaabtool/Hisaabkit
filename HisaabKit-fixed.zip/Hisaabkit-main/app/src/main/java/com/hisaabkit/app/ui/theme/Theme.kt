package com.hisaabkit.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = HisaabKitPrimary,
    onPrimary = Color.White,
    primaryContainer = HisaabKitPrimaryContainer,
    onPrimaryContainer = HisaabKitOnPrimaryContainer,
    secondary = HisaabKitPurple,
    onSecondary = Color.White,
    tertiary = HisaabKitOrange,
    onTertiary = Color.White,
    background = HisaabKitBackground,
    onBackground = HisaabKitOnPrimaryContainer,
    surface = HisaabKitSurface,
    onSurface = HisaabKitOnPrimaryContainer,
    surfaceVariant = HisaabKitCard,
    onSurfaceVariant = Color(0xFF625A70),
    outline = Color(0xFF79747E)
)

private val DarkColors = darkColorScheme(
    primary = HisaabKitPrimaryDark,
    onPrimary = HisaabKitOnPrimaryDark,
    primaryContainer = HisaabKitPrimaryContainerDark,
    onPrimaryContainer = HisaabKitOnPrimaryContainerDark,
    secondary = Color(0xFFD0BCFF),
    onSecondary = Color(0xFF35205F),
    tertiary = Color(0xFFFFB77A),
    onTertiary = Color(0xFF4A2500),
    background = HisaabKitBackgroundDark,
    onBackground = HisaabKitOnBackgroundDark,
    surface = HisaabKitSurfaceDark,
    onSurface = HisaabKitOnSurfaceDark,
    surfaceVariant = HisaabKitSurfaceVariantDark,
    onSurfaceVariant = HisaabKitOnSurfaceVariantDark,
    outline = Color(0xFF938F99)
)

@Composable
fun HisaabKitTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = HisaabKitTypography,
        content = content
    )
}
