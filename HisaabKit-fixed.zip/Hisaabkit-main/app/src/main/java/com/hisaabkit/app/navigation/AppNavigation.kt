package com.hisaabkit.app.navigation

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.hisaabkit.app.tools.bike.BikeEmiScreen
import com.hisaabkit.app.tools.emi.EmiScreen
import com.hisaabkit.app.tools.land.LandCalculatorScreen
import com.hisaabkit.app.tools.photo.PhotoResizerScreen
import com.hisaabkit.app.tools.prepayment.PrepaymentScreen
import com.hisaabkit.app.ui.screens.BasicToolScreen
import com.hisaabkit.app.ui.screens.HomeScreen
import com.hisaabkit.app.ui.screens.HisaabKitTools
import com.hisaabkit.app.ui.screens.SettingsScreen
import com.hisaabkit.app.ui.screens.ToolsScreen

object Routes {
    const val HOME = "home"
    const val TOOLS = "tools"
    const val SETTINGS = "settings"
    const val EMI = "emi"
    const val BIKE = "bike"
    const val PREPAYMENT = "prepayment"
    const val LAND = "land"
    const val PHOTO = "photo"
}

data class BottomItem(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private const val PREFS = "hisaabkit_prefs"
private const val FAVORITES = "favorites"
private const val RECENT = "recent"

private fun openTool(nav: androidx.navigation.NavHostController, title: String) {
    when (title) {
        "EMI Calculator" -> nav.navigate(Routes.EMI)
        "Bike Loan EMI" -> nav.navigate(Routes.BIKE)
        "EMI Prepayment" -> nav.navigate(Routes.PREPAYMENT)
        "Bigha / Biswa" -> nav.navigate(Routes.LAND)
        "Photo Resizer" -> nav.navigate(Routes.PHOTO)
        else -> nav.navigate("basic/${title.hashCode()}")
    }
}

@Composable
fun AppNavigation(themeMode: String, onThemeModeChange: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val navController = rememberNavController()
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var favorites by remember { mutableStateOf(prefs.getStringSet(FAVORITES, emptySet())?.toSet() ?: emptySet()) }
    var recent by remember { mutableStateOf(prefs.getString(RECENT, "")?.split("|")?.filter { it.isNotBlank() } ?: emptyList()) }

    fun toggleFavorite(title: String) {
        val next = favorites.toMutableSet().apply { if (!add(title)) remove(title) }
        favorites = next
        prefs.edit().putStringSet(FAVORITES, next).apply()
    }
    fun rememberTool(title: String) {
        recent = (listOf(title) + recent.filterNot { it == title }).take(6)
        prefs.edit().putString(RECENT, recent.joinToString("|")).apply()
    }
    fun launch(title: String) { rememberTool(title); openTool(navController, title) }

    val currentRoute by navController.currentBackStackEntryAsState()
    val route = currentRoute?.destination?.route
    val showBottom = route == Routes.HOME || route == Routes.TOOLS || route == Routes.SETTINGS
    val bottomItems = listOf(
        BottomItem(Routes.HOME, "Home", Icons.Default.Home),
        BottomItem(Routes.TOOLS, "Tools", Icons.Default.Calculate),
        BottomItem(Routes.SETTINGS, "Settings", Icons.Default.Settings)
    )

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            if (showBottom) NavigationBar(tonalElevation = 8.dp) {
                bottomItems.forEach { item ->
                    val selected = route == item.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            if (!selected) navController.navigate(item.route) {
                                popUpTo(Routes.HOME) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, item.title) },
                        label = { Text(item.title, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }
    ) { padding ->
        NavHost(navController, startDestination = Routes.HOME, modifier = Modifier.padding(padding)) {
            composable(Routes.HOME) { HomeScreen(favorites, recent, ::toggleFavorite, ::launch) }
            composable(Routes.TOOLS) { ToolsScreen(favorites, ::toggleFavorite, ::launch) }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    themeMode = themeMode,
                    onThemeModeChange = onThemeModeChange,
                    favoriteCount = favorites.size,
                    recentCount = recent.size,
                    onClearData = {
                        favorites = emptySet(); recent = emptyList()
                        prefs.edit().remove(FAVORITES).remove(RECENT).apply()
                    }
                )
            }
            composable(Routes.EMI) { BackHandler { navController.popBackStack() }; EmiScreen() }
            composable(Routes.BIKE) { BackHandler { navController.popBackStack() }; BikeEmiScreen() }
            composable(Routes.PREPAYMENT) { BackHandler { navController.popBackStack() }; PrepaymentScreen() }
            composable(Routes.LAND) { BackHandler { navController.popBackStack() }; LandCalculatorScreen() }
            composable(Routes.PHOTO) { BackHandler { navController.popBackStack() }; PhotoResizerScreen() }
            composable("basic/{id}") { backStack ->
                BackHandler { navController.popBackStack() }
                val id = backStack.arguments?.getString("id")?.toIntOrNull()
                val title = HisaabKitTools.firstOrNull { it.title.hashCode() == id }?.title ?: "Percentage Calculator"
                BasicToolScreen(title)
            }
        }
    }
}
