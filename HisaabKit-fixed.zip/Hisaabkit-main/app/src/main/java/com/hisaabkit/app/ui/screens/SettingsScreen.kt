package com.hisaabkit.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hisaabkit.app.ui.theme.HisaabKitBlue
import com.hisaabkit.app.ui.theme.HisaabKitGreen
import com.hisaabkit.app.ui.theme.HisaabKitPurple

@Composable
fun SettingsScreen(
    themeMode: String,
    onThemeModeChange: (String) -> Unit,
    favoriteCount: Int,
    recentCount: Int,
    onClearData: () -> Unit
) {
    val context = LocalContext.current
    var showTheme by remember { mutableStateOf(false) }
    var showPrivacy by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings ⚙️", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        Text("App को अपनी पसंद के अनुसार सेट करें", color = MaterialTheme.colorScheme.onSurfaceVariant)

        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
            Row(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(HisaabKitPurple, HisaabKitBlue)), RoundedCornerShape(26.dp)).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PhoneAndroid, null, tint = Color.White, modifier = Modifier.size(42.dp))
                Spacer(Modifier.size(14.dp))
                Column {
                    Text("HisaabKit", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                    Text("Version 2.0 • Fast & Private", color = Color.White.copy(.88f))
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Favorites", favoriteCount.toString(), HisaabKitPurple, Modifier.weight(1f))
            StatCard("Recent", recentCount.toString(), HisaabKitBlue, Modifier.weight(1f))
        }

        Text("Preferences", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        SettingCard(Icons.Default.DarkMode, "Appearance", when (themeMode) { "dark" -> "Dark mode"; "light" -> "Light mode"; else -> "System default" }, HisaabKitPurple) { showTheme = true }
        SettingCard(Icons.Default.Lock, "Privacy & Data", "Calculations device पर ही रहते हैं", HisaabKitBlue) { showPrivacy = true }
        SettingCard(Icons.Default.DeleteSweep, "Clear Favorites & Recent", "Saved app data हटाएँ", Color(0xFFDC2626)) { showClear = true }

        Text("More", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        SettingCard(Icons.Default.Share, "Share HisaabKit", "दोस्तों के साथ app share करें", HisaabKitGreen) {
            context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "HisaabKit — आसान और तेज़ calculators app") }, "Share HisaabKit"))
        }
        SettingCard(Icons.Default.Star, "Rate HisaabKit", "Play Store पर rating दें", Color(0xFFF59E0B)) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${context.packageName}"))
            try { context.startActivity(intent) } catch (_: Exception) { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${context.packageName}"))) }
        }
        SettingCard(Icons.Default.Info, "About HisaabKit", "Version और app information", HisaabKitPurple) { showAbout = true }
    }

    if (showTheme) AlertDialog(onDismissRequest = { showTheme = false }, title = { Text("Appearance") }, text = {
        Column {
            ThemeChoice("System default", "system", themeMode, onThemeModeChange) { showTheme = false }
            ThemeChoice("Light", "light", themeMode, onThemeModeChange) { showTheme = false }
            ThemeChoice("Dark", "dark", themeMode, onThemeModeChange) { showTheme = false }
        }
    }, confirmButton = { TextButton({ showTheme = false }) { Text("Done") } })

    if (showPrivacy) AlertDialog(onDismissRequest = { showPrivacy = false }, title = { Text("Privacy & Data") }, text = { Text("HisaabKit के calculators local रूप से calculation करते हैं। Favorites और recent tools केवल इसी device की app storage में रखे जाते हैं।") }, confirmButton = { TextButton({ showPrivacy = false }) { Text("OK") } })
    if (showAbout) AlertDialog(onDismissRequest = { showAbout = false }, title = { Text("About HisaabKit") }, text = { Text("HisaabKit एक simple, fast और useful calculation app है।\n\nTools: EMI, Bike Loan, Prepayment, Land, Photo, SIP, GST, Percentage, Discount, Age, BMI और Unit Converter.") }, confirmButton = { TextButton({ showAbout = false }) { Text("OK") } })
    if (showClear) AlertDialog(onDismissRequest = { showClear = false }, title = { Text("Clear saved data?") }, text = { Text("Favorites और recently used list हट जाएगी।") }, dismissButton = { TextButton({ showClear = false }) { Text("Cancel") } }, confirmButton = { TextButton({ onClearData(); showClear = false }) { Text("Clear") } })
}

@Composable private fun ThemeChoice(label: String, value: String, selected: String, onSelect: (String) -> Unit, close: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onSelect(value); close() }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected == value, onClick = { onSelect(value); close() })
        Text(label)
    }
}

@Composable private fun StatCard(title: String, value: String, color: Color, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = color.copy(.10f)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp)) { Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold); Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable private fun SettingCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, color: Color, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = color.copy(.10f))) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.foundation.layout.Box(Modifier.size(48.dp).background(color, RoundedCornerShape(15.dp)), Alignment.Center) { Icon(icon, null, tint = Color.White) }
            Spacer(Modifier.size(14.dp)); Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
