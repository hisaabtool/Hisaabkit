package com.hisaabkit.app.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.ui.graphics.vector.ImageVector

const val CAT_ALL = "सभी"
const val CAT_FINANCE = "Finance"
const val CAT_LAND = "Land"
const val CAT_DAILY = "Daily"
const val CAT_PHOTO = "Photo"

val HisaabKitTools = listOf(
    Tool("EMI Calculator", "Loan EMI और interest", Icons.Default.Calculate, CAT_FINANCE, true),
    Tool("Bike Loan EMI", "Bike loan का हिसाब", Icons.Default.AccountBalance, CAT_FINANCE, true),
    Tool("EMI Prepayment", "Loan जल्दी खत्म करें", Icons.Default.TrendingUp, CAT_FINANCE, true),
    Tool("SIP Calculator", "Investment का अनुमान", Icons.Default.Savings, CAT_FINANCE, true),
    Tool("GST Calculator", "GST जोड़ें या घटाएँ", Icons.Default.ReceiptLong, CAT_FINANCE, false),
    Tool("Percentage Calculator", "प्रतिशत जल्दी निकालें", Icons.Default.Percent, CAT_DAILY, false),
    Tool("Simple Calculator", "जोड़, घटाव, गुणा, भाग", Icons.Default.Calculate, CAT_DAILY, false),
    Tool("Discount Calculator", "छूट के बाद कीमत", Icons.Default.LocalOffer, CAT_DAILY, false),
    Tool("Age Calculator", "उम्र और अगली birthday", Icons.Default.Cake, CAT_DAILY, false),
    Tool("BMI Calculator", "Height और weight से BMI", Icons.Default.MonitorWeight, CAT_DAILY, false),
    Tool("Unit Converter", "Length, weight और area", Icons.Default.SwapHoriz, CAT_DAILY, false),
    Tool("Bigha / Biswa", "जमीन का area", Icons.Default.Home, CAT_LAND, true),
    Tool("Photo Resizer", "Photo size कम करें", Icons.Default.Image, CAT_PHOTO, true)
)

data class Tool(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val category: String = CAT_DAILY,
    val popular: Boolean = false
)

fun getToolColor(title: String) = when (title) {
    "EMI Calculator" -> com.hisaabkit.app.ui.theme.HisaabKitPurple
    "Bike Loan EMI" -> com.hisaabkit.app.ui.theme.HisaabKitBlue
    "EMI Prepayment" -> com.hisaabkit.app.ui.theme.HisaabKitGreen
    "SIP Calculator" -> com.hisaabkit.app.ui.theme.HisaabKitCyan
    "GST Calculator" -> com.hisaabkit.app.ui.theme.HisaabKitBlue
    "Percentage Calculator" -> com.hisaabkit.app.ui.theme.HisaabKitPurple
    "Discount Calculator" -> com.hisaabkit.app.ui.theme.HisaabKitPink
    "Age Calculator" -> com.hisaabkit.app.ui.theme.HisaabKitOrange
    "BMI Calculator" -> com.hisaabkit.app.ui.theme.HisaabKitGreen
    "Unit Converter" -> com.hisaabkit.app.ui.theme.HisaabKitCyan
    "Bigha / Biswa" -> com.hisaabkit.app.ui.theme.HisaabKitOrange
    "Photo Resizer" -> com.hisaabkit.app.ui.theme.HisaabKitPink
    else -> com.hisaabkit.app.ui.theme.HisaabKitPurple
}
