package com.hisaabkit.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(
    favorites: Set<String>,
    recent: List<String>,
    onFavorite: (String) -> Unit,
    onToolClick: (String) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(CAT_ALL) }
    val visible = HisaabKitTools.filter { tool ->
        val matchSearch = search.isBlank() || tool.title.contains(search, true) || tool.subtitle.contains(search, true)
        val matchCategory = category == CAT_ALL || tool.category == category
        matchSearch && matchCategory
    }
    val popular = HisaabKitTools.filter { it.popular }.take(5)
    val recentTools = recent.mapNotNull { title -> HisaabKitTools.find { it.title == title } }.take(4)

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(2) }) { HeaderCard() }
        item(span = { GridItemSpan(2) }) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                placeholder = { Text("कोई calculator खोजें...") },
                leadingIcon = { Icon(Icons.Default.Search, "Search") },
                trailingIcon = {
                    if (search.isNotEmpty()) IconButton({ search = "" }) { Icon(Icons.Default.Clear, "Clear") }
                }
            )
        }
        item(span = { GridItemSpan(2) }) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected = category == CAT_ALL, onClick = { category = CAT_ALL }, label = { Text(CAT_ALL) }) }
                item { FilterChip(selected = category == CAT_FINANCE, onClick = { category = CAT_FINANCE }, label = { Text("Finance") }) }
                item { FilterChip(selected = category == CAT_LAND, onClick = { category = CAT_LAND }, label = { Text("Land") }) }
                item { FilterChip(selected = category == CAT_DAILY, onClick = { category = CAT_DAILY }, label = { Text("Daily") }) }
                item { FilterChip(selected = category == CAT_PHOTO, onClick = { category = CAT_PHOTO }, label = { Text("Photo") }) }
            }
        }
        if (search.isBlank() && category == CAT_ALL) {
            item(span = { GridItemSpan(2) }) { SectionTitle("Popular Tools", "सबसे ज्यादा काम आने वाले tools", HisaabKitTools.size) }
            items(popular, key = { it.title }) { tool -> ToolCard(tool, favorites.contains(tool.title), onFavorite, onToolClick) }
            if (recentTools.isNotEmpty()) {
                item(span = { GridItemSpan(2) }) { SectionTitle("Recently Used", "हाल में खोले गए tools", recentTools.size) }
                items(recentTools, key = { "recent_${it.title}" }) { tool -> ToolCard(tool, favorites.contains(tool.title), onFavorite, onToolClick) }
            }
            item(span = { GridItemSpan(2) }) { SectionTitle("All Tools", "13 useful tools एक ही जगह", HisaabKitTools.size) }
        }
        items(if (search.isBlank() && category == CAT_ALL) HisaabKitTools.filter { !it.popular } else visible, key = { it.title }) { tool -> ToolCard(tool, favorites.contains(tool.title), onFavorite, onToolClick) }
        if (visible.isEmpty()) item(span = { GridItemSpan(2) }) { EmptyState(search) }
        item(span = { GridItemSpan(2) }) { TipCard() }
    }
}

@Composable private fun SectionTitle(title: String, subtitle: String, count: Int) {
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        AssistChip(onClick = {}, label = { Text("$count") })
    }
}

@Composable private fun HeaderCard() {
    Box(Modifier.fillMaxWidth().height(180.dp).shadow(10.dp, RoundedCornerShape(28.dp)).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(com.hisaabkit.app.ui.theme.HisaabKitPurple, com.hisaabkit.app.ui.theme.HisaabKitBlue, Color(0xFF06B6D4)))).padding(20.dp)) {
        Box(Modifier.size(130.dp).align(Alignment.TopEnd).clip(CircleShape).background(Color.White.copy(.08f)))
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(Color.White.copy(.18f)), Alignment.Center) {
                    Icon(Icons.Default.Calculate, "HisaabKit", tint = Color.White, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("HisaabKit", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("Smart हिसाब • आसान जिंदगी", color = Color.White.copy(.9f))
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("हर calculation अब आसान है ✨", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text("EMI, Loan, Land, GST, SIP, BMI और Photo tools एक ही जगह।", color = Color.White.copy(.88f), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable private fun ToolCard(tool: Tool, favorite: Boolean, onFavorite: (String) -> Unit, onClick: (String) -> Unit) {
    val color = getToolColor(tool.title)
    Card(onClick = { onClick(tool.title) }, modifier = Modifier.fillMaxWidth().height(172.dp), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = color.copy(.10f)), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.fillMaxSize().padding(15.dp), Arrangement.SpaceBetween) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.Top) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(color), Alignment.Center) { Icon(tool.icon, tool.title, tint = Color.White, modifier = Modifier.size(28.dp)) }
                IconButton(onClick = { onFavorite(tool.title) }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Star, "Favorite", tint = if (favorite) color else MaterialTheme.colorScheme.onSurfaceVariant.copy(.55f)) }
            }
            Column {
                Text(tool.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(3.dp))
                Text(tool.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable private fun EmptyState(query: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("कोई tool नहीं मिला", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("\"$query\" के लिए दूसरा नाम या keyword आज़माएँ।", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable private fun TipCard() {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = com.hisaabkit.app.ui.theme.HisaabKitGreen.copy(.10f))) {
        Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(45.dp).clip(RoundedCornerShape(14.dp)).background(com.hisaabkit.app.ui.theme.HisaabKitGreen), Alignment.Center) { Text("✓", color = Color.White, fontWeight = FontWeight.ExtraBold) }
            Spacer(Modifier.width(13.dp))
            Column { Text("Quick & Easy", fontWeight = FontWeight.Bold); Text("Favorite और recent tools से अगली बार काम और तेज़ करें।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
