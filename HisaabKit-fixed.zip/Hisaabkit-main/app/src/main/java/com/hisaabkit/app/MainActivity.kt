package com.hisaabkit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.hisaabkit.app.navigation.AppNavigation
import com.hisaabkit.app.ui.theme.HisaabKitTheme

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("hisaabkit_prefs", MODE_PRIVATE) }
    private var themeMode by mutableStateOf("system")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        themeMode = prefs.getString("theme_mode", "system") ?: "system"
        setContent {
            val dark = when (themeMode) {
                "dark" -> true
                "light" -> false
                else -> androidx.compose.foundation.isSystemInDarkTheme()
            }
            HisaabKitTheme(darkTheme = dark) {
                AppNavigation(
                    themeMode = themeMode,
                    onThemeModeChange = {
                        themeMode = it
                        prefs.edit().putString("theme_mode", it).apply()
                    }
                )
            }
        }
    }
}
