package com.hisaabkit.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import kotlin.math.pow

@Composable
fun BasicToolScreen(title: String) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var c by remember { mutableStateOf("") }
    var d by remember { mutableStateOf("") }
    var operation by remember { mutableStateOf("+") }
    var result by remember { mutableStateOf<String?>(null) }

    val tool = HisaabKitTools.first { it.title == title }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(tool.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        Text(tool.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)

        when (title) {
            "Percentage Calculator" -> {
                NumberField("पहली संख्या", a) { a = it }
                NumberField("दूसरी संख्या", b) { b = it }
            }
            "Discount Calculator" -> {
                NumberField("Original price (₹)", a) { a = it }
                NumberField("Discount (%)", b) { b = it }
            }
            "GST Calculator" -> {
                NumberField("Amount (₹)", a) { a = it }
                NumberField("GST (%)", b) { b = it }
            }
            "SIP Calculator" -> {
                NumberField("Monthly investment (₹)", a) { a = it }
                NumberField("Annual return (%)", b) { b = it }
                NumberField("Time (years)", c) { c = it }
            }
            "BMI Calculator" -> {
                NumberField("Weight (kg)", a) { a = it }
                NumberField("Height (cm)", b) { b = it }
            }
            "Age Calculator" -> {
                NumberField("Birth year", a) { a = it }
                NumberField("Current year", b) { b = it }
                Text("उदाहरण: 1999 और 2026", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            "Unit Converter" -> {
                NumberField("Meters", a) { a = it }
                Text("मीटर को फीट में बदलें", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            "Simple Calculator" -> {
                NumberField("पहली संख्या", a) { a = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("+", "−", "×", "÷").forEach { op -> FilterChip(selected = operation == op, onClick = { operation = op }, label = { Text(op) }) }
                }
                NumberField("दूसरी संख्या", b) { b = it }
            }
        }

        Button(onClick = {
            result = calculate(title, a, b, c, operation)
        }, modifier = Modifier.fillMaxWidth()) { Text("Calculate") }

        result?.let { value ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = getToolColor(title).copy(.10f))) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Result", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = { if (it.length <= 14) onValueChange(it) }, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
}

private fun n(s: String) = s.toDoubleOrNull()
private fun fmt(v: Double) = if (v.isNaN() || v.isInfinite()) "कृपया सही value भरें" else String.format("%.2f", v)

private fun calculate(title: String, a: String, b: String, c: String, operation: String): String {
    val x = n(a); val y = n(b); val z = n(c)
    return when (title) {
        "Percentage Calculator" -> if (x != null && y != null) "${fmt((x / 100.0) * y)}" else "कृपया सही value भरें"
        "Discount Calculator" -> if (x != null && y != null) "Final price: ₹${fmt(x - x * y / 100)}\nबचत: ₹${fmt(x * y / 100)}" else "कृपया सही value भरें"
        "GST Calculator" -> if (x != null && y != null) "GST: ₹${fmt(x * y / 100)}\nTotal: ₹${fmt(x + x * y / 100)}" else "कृपया सही value भरें"
        "SIP Calculator" -> if (x != null && y != null && z != null && x >= 0 && z >= 0) {
            val months = z * 12; val r = y / 12 / 100
            val future = if (r == 0.0) x * months else x * (((1 + r).pow(months) - 1) / r) * (1 + r)
            val invested = x * months
            "Future value: ₹${fmt(future)}\nInvested: ₹${fmt(invested)}\nEstimated gain: ₹${fmt(future - invested)}"
        } else "कृपया सही value भरें"
        "BMI Calculator" -> if (x != null && y != null && y > 0) "BMI: ${fmt(x / (y / 100).pow(2))}" else "कृपया सही value भरें"
        "Age Calculator" -> if (x != null && y != null && y >= x) "लगभग उम्र: ${fmt(y - x)} साल" else "कृपया सही year भरें"
        "Unit Converter" -> if (x != null) "Feet: ${fmt(x * 3.28084)} ft" else "कृपया सही value भरें"
        "Simple Calculator" -> if (x != null && y != null) when (operation) { "+" -> fmt(x + y); "−" -> fmt(x - y); "×" -> fmt(x * y); "÷" -> if (y == 0.0) "0 से divide नहीं कर सकते" else fmt(x / y); else -> "कृपया सही value भरें" } else "कृपया सही value भरें"
        else -> "यह tool उपलब्ध नहीं है"
    }
}
