# HisaabKit

HisaabKit is an Android Jetpack Compose calculator app.

## Included features
- EMI Calculator
- Bike Loan EMI
- EMI Prepayment
- Bigha / Biswa land calculator
- Photo Resizer
- SIP Calculator
- GST Calculator
- Percentage Calculator
- Simple Calculator
- Discount Calculator
- Age Calculator
- BMI Calculator
- Unit Converter
- Search + category filters
- Favorites saved on device
- Recently used tools
- Light / Dark / System appearance
- Privacy, About, Share and Rate actions
- Improved dark-mode contrast and system-bar spacing
- GitHub Actions build pinned to Gradle 8.9
